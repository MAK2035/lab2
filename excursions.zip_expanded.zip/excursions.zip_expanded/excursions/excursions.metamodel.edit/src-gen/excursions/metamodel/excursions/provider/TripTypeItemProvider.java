/**
 */
package excursions.metamodel.excursions.provider;

import excursions.metamodel.excursions.ExcursionsPackage;
import excursions.metamodel.excursions.TripType;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IEditingDomainItemProvider;
import org.eclipse.emf.edit.provider.IItemLabelProvider;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.IItemPropertySource;
import org.eclipse.emf.edit.provider.IStructuredItemContentProvider;
import org.eclipse.emf.edit.provider.ITreeItemContentProvider;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemProviderAdapter;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link excursions.metamodel.excursions.TripType} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TripTypeItemProvider extends ItemProviderAdapter implements IEditingDomainItemProvider,
		IStructuredItemContentProvider, ITreeItemContentProvider, IItemLabelProvider, IItemPropertySource {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripTypeItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addTripIDPropertyDescriptor(object);
			addTripNamePropertyDescriptor(object);
			addDescriptionPropertyDescriptor(object);
			addDurationPropertyDescriptor(object);
			addPricePropertyDescriptor(object);
			addHistoryculturePropertyDescriptor(object);
			addNatureoutdoorPropertyDescriptor(object);
			addThrilladventurePropertyDescriptor(object);
			addShoppingsightseeingPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Trip ID feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTripIDPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_TripID_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_TripID_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__TRIP_ID, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Trip Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addTripNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_TripName_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_TripName_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__TRIP_NAME, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Description feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDescriptionPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_Description_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_Description_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__DESCRIPTION, true, false, false,
						ItemPropertyDescriptor.GENERIC_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Duration feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addDurationPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_Duration_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_Duration_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__DURATION, true, false, false,
						ItemPropertyDescriptor.INTEGRAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Price feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addPricePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_Price_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_Price_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__PRICE, true, false, false,
						ItemPropertyDescriptor.REAL_VALUE_IMAGE, null, null));
	}

	/**
	 * This adds a property descriptor for the Historyculture feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addHistoryculturePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_historyculture_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_historyculture_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__HISTORYCULTURE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Natureoutdoor feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNatureoutdoorPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_natureoutdoor_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_natureoutdoor_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__NATUREOUTDOOR, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Thrilladventure feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addThrilladventurePropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_thrilladventure_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_thrilladventure_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__THRILLADVENTURE, true, false, true, null, null, null));
	}

	/**
	 * This adds a property descriptor for the Shoppingsightseeing feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addShoppingsightseeingPropertyDescriptor(Object object) {
		itemPropertyDescriptors
				.add(createItemPropertyDescriptor(((ComposeableAdapterFactory) adapterFactory).getRootAdapterFactory(),
						getResourceLocator(), getString("_UI_TripType_shoppingsightseeing_feature"),
						getString("_UI_PropertyDescriptor_description", "_UI_TripType_shoppingsightseeing_feature",
								"_UI_TripType_type"),
						ExcursionsPackage.Literals.TRIP_TYPE__SHOPPINGSIGHTSEEING, true, false, true, null, null,
						null));
	}

	/**
	 * This returns TripType.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/TripType"));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean shouldComposeCreationImage() {
		return true;
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((TripType) object).getTripName();
		return label == null || label.length() == 0 ? getString("_UI_TripType_type")
				: getString("_UI_TripType_type") + " " + label;
	}

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(TripType.class)) {
		case ExcursionsPackage.TRIP_TYPE__TRIP_ID:
		case ExcursionsPackage.TRIP_TYPE__TRIP_NAME:
		case ExcursionsPackage.TRIP_TYPE__DESCRIPTION:
		case ExcursionsPackage.TRIP_TYPE__DURATION:
		case ExcursionsPackage.TRIP_TYPE__PRICE:
			fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
			return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

	/**
	 * Return the resource locator for this item provider's resources.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		return ExcursionsEditPlugin.INSTANCE;
	}

}
