/**
 */
package excursions.metamodel.excursions;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Nature Outdoor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.NatureOutdoor#getNatureCites <em>Nature Cites</em>}</li>
 * </ul>
 *
 * @see excursions.metamodel.excursions.ExcursionsPackage#getNatureOutdoor()
 * @model
 * @generated
 */
public interface NatureOutdoor extends TripType {
	/**
	 * Returns the value of the '<em><b>Nature Cites</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nature Cites</em>' attribute.
	 * @see #setNatureCites(String)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getNatureOutdoor_NatureCites()
	 * @model
	 * @generated
	 */
	String getNatureCites();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.NatureOutdoor#getNatureCites <em>Nature Cites</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nature Cites</em>' attribute.
	 * @see #getNatureCites()
	 * @generated
	 */
	void setNatureCites(String value);

} // NatureOutdoor
