/**
 */
package excursions.metamodel.excursions;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see excursions.metamodel.excursions.ExcursionsFactory
 * @model kind="package"
 * @generated
 */
public interface ExcursionsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "excursions";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.rm2pt.com/excursions";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "excursions";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ExcursionsPackage eINSTANCE = excursions.metamodel.excursions.impl.ExcursionsPackageImpl.init();

	/**
	 * The meta object id for the '{@link excursions.metamodel.excursions.impl.TripTypeImpl <em>Trip Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see excursions.metamodel.excursions.impl.TripTypeImpl
	 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getTripType()
	 * @generated
	 */
	int TRIP_TYPE = 0;

	/**
	 * The feature id for the '<em><b>Trip ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__TRIP_ID = 0;

	/**
	 * The feature id for the '<em><b>Trip Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__TRIP_NAME = 1;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__DESCRIPTION = 2;

	/**
	 * The feature id for the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__DURATION = 3;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__PRICE = 4;

	/**
	 * The feature id for the '<em><b>Historyculture</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__HISTORYCULTURE = 5;

	/**
	 * The feature id for the '<em><b>Natureoutdoor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__NATUREOUTDOOR = 6;

	/**
	 * The feature id for the '<em><b>Thrilladventure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__THRILLADVENTURE = 7;

	/**
	 * The feature id for the '<em><b>Shoppingsightseeing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE__SHOPPINGSIGHTSEEING = 8;

	/**
	 * The number of structural features of the '<em>Trip Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Trip Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link excursions.metamodel.excursions.impl.ExcursionAppImpl <em>Excursion App</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see excursions.metamodel.excursions.impl.ExcursionAppImpl
	 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getExcursionApp()
	 * @generated
	 */
	int EXCURSION_APP = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXCURSION_APP__NAME = 0;

	/**
	 * The feature id for the '<em><b>Trips</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXCURSION_APP__TRIPS = 1;

	/**
	 * The number of structural features of the '<em>Excursion App</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXCURSION_APP_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Excursion App</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXCURSION_APP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link excursions.metamodel.excursions.impl.HistoryCultureImpl <em>History Culture</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see excursions.metamodel.excursions.impl.HistoryCultureImpl
	 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getHistoryCulture()
	 * @generated
	 */
	int HISTORY_CULTURE = 2;

	/**
	 * The feature id for the '<em><b>Trip ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__TRIP_ID = TRIP_TYPE__TRIP_ID;

	/**
	 * The feature id for the '<em><b>Trip Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__TRIP_NAME = TRIP_TYPE__TRIP_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__DESCRIPTION = TRIP_TYPE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__DURATION = TRIP_TYPE__DURATION;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__PRICE = TRIP_TYPE__PRICE;

	/**
	 * The feature id for the '<em><b>Historyculture</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__HISTORYCULTURE = TRIP_TYPE__HISTORYCULTURE;

	/**
	 * The feature id for the '<em><b>Natureoutdoor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__NATUREOUTDOOR = TRIP_TYPE__NATUREOUTDOOR;

	/**
	 * The feature id for the '<em><b>Thrilladventure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__THRILLADVENTURE = TRIP_TYPE__THRILLADVENTURE;

	/**
	 * The feature id for the '<em><b>Shoppingsightseeing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__SHOPPINGSIGHTSEEING = TRIP_TYPE__SHOPPINGSIGHTSEEING;

	/**
	 * The feature id for the '<em><b>Historic Cites</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE__HISTORIC_CITES = TRIP_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>History Culture</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE_FEATURE_COUNT = TRIP_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>History Culture</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HISTORY_CULTURE_OPERATION_COUNT = TRIP_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link excursions.metamodel.excursions.impl.NatureOutdoorImpl <em>Nature Outdoor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see excursions.metamodel.excursions.impl.NatureOutdoorImpl
	 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getNatureOutdoor()
	 * @generated
	 */
	int NATURE_OUTDOOR = 3;

	/**
	 * The feature id for the '<em><b>Trip ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__TRIP_ID = TRIP_TYPE__TRIP_ID;

	/**
	 * The feature id for the '<em><b>Trip Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__TRIP_NAME = TRIP_TYPE__TRIP_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__DESCRIPTION = TRIP_TYPE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__DURATION = TRIP_TYPE__DURATION;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__PRICE = TRIP_TYPE__PRICE;

	/**
	 * The feature id for the '<em><b>Historyculture</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__HISTORYCULTURE = TRIP_TYPE__HISTORYCULTURE;

	/**
	 * The feature id for the '<em><b>Natureoutdoor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__NATUREOUTDOOR = TRIP_TYPE__NATUREOUTDOOR;

	/**
	 * The feature id for the '<em><b>Thrilladventure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__THRILLADVENTURE = TRIP_TYPE__THRILLADVENTURE;

	/**
	 * The feature id for the '<em><b>Shoppingsightseeing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__SHOPPINGSIGHTSEEING = TRIP_TYPE__SHOPPINGSIGHTSEEING;

	/**
	 * The feature id for the '<em><b>Nature Cites</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR__NATURE_CITES = TRIP_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Nature Outdoor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR_FEATURE_COUNT = TRIP_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Nature Outdoor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATURE_OUTDOOR_OPERATION_COUNT = TRIP_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link excursions.metamodel.excursions.impl.ThrillAdventureImpl <em>Thrill Adventure</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see excursions.metamodel.excursions.impl.ThrillAdventureImpl
	 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getThrillAdventure()
	 * @generated
	 */
	int THRILL_ADVENTURE = 4;

	/**
	 * The feature id for the '<em><b>Trip ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__TRIP_ID = TRIP_TYPE__TRIP_ID;

	/**
	 * The feature id for the '<em><b>Trip Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__TRIP_NAME = TRIP_TYPE__TRIP_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__DESCRIPTION = TRIP_TYPE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__DURATION = TRIP_TYPE__DURATION;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__PRICE = TRIP_TYPE__PRICE;

	/**
	 * The feature id for the '<em><b>Historyculture</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__HISTORYCULTURE = TRIP_TYPE__HISTORYCULTURE;

	/**
	 * The feature id for the '<em><b>Natureoutdoor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__NATUREOUTDOOR = TRIP_TYPE__NATUREOUTDOOR;

	/**
	 * The feature id for the '<em><b>Thrilladventure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__THRILLADVENTURE = TRIP_TYPE__THRILLADVENTURE;

	/**
	 * The feature id for the '<em><b>Shoppingsightseeing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__SHOPPINGSIGHTSEEING = TRIP_TYPE__SHOPPINGSIGHTSEEING;

	/**
	 * The feature id for the '<em><b>Activities</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE__ACTIVITIES = TRIP_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Thrill Adventure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE_FEATURE_COUNT = TRIP_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Thrill Adventure</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int THRILL_ADVENTURE_OPERATION_COUNT = TRIP_TYPE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link excursions.metamodel.excursions.impl.ShoppingSightseeingImpl <em>Shopping Sightseeing</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see excursions.metamodel.excursions.impl.ShoppingSightseeingImpl
	 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getShoppingSightseeing()
	 * @generated
	 */
	int SHOPPING_SIGHTSEEING = 5;

	/**
	 * The feature id for the '<em><b>Trip ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__TRIP_ID = TRIP_TYPE__TRIP_ID;

	/**
	 * The feature id for the '<em><b>Trip Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__TRIP_NAME = TRIP_TYPE__TRIP_NAME;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__DESCRIPTION = TRIP_TYPE__DESCRIPTION;

	/**
	 * The feature id for the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__DURATION = TRIP_TYPE__DURATION;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__PRICE = TRIP_TYPE__PRICE;

	/**
	 * The feature id for the '<em><b>Historyculture</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__HISTORYCULTURE = TRIP_TYPE__HISTORYCULTURE;

	/**
	 * The feature id for the '<em><b>Natureoutdoor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__NATUREOUTDOOR = TRIP_TYPE__NATUREOUTDOOR;

	/**
	 * The feature id for the '<em><b>Thrilladventure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__THRILLADVENTURE = TRIP_TYPE__THRILLADVENTURE;

	/**
	 * The feature id for the '<em><b>Shoppingsightseeing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__SHOPPINGSIGHTSEEING = TRIP_TYPE__SHOPPINGSIGHTSEEING;

	/**
	 * The feature id for the '<em><b>Attractions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING__ATTRACTIONS = TRIP_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Shopping Sightseeing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING_FEATURE_COUNT = TRIP_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Shopping Sightseeing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHOPPING_SIGHTSEEING_OPERATION_COUNT = TRIP_TYPE_OPERATION_COUNT + 0;

	/**
	 * Returns the meta object for class '{@link excursions.metamodel.excursions.TripType <em>Trip Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trip Type</em>'.
	 * @see excursions.metamodel.excursions.TripType
	 * @generated
	 */
	EClass getTripType();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.TripType#getTripID <em>Trip ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trip ID</em>'.
	 * @see excursions.metamodel.excursions.TripType#getTripID()
	 * @see #getTripType()
	 * @generated
	 */
	EAttribute getTripType_TripID();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.TripType#getTripName <em>Trip Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trip Name</em>'.
	 * @see excursions.metamodel.excursions.TripType#getTripName()
	 * @see #getTripType()
	 * @generated
	 */
	EAttribute getTripType_TripName();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.TripType#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see excursions.metamodel.excursions.TripType#getDescription()
	 * @see #getTripType()
	 * @generated
	 */
	EAttribute getTripType_Description();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.TripType#getDuration <em>Duration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Duration</em>'.
	 * @see excursions.metamodel.excursions.TripType#getDuration()
	 * @see #getTripType()
	 * @generated
	 */
	EAttribute getTripType_Duration();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.TripType#getPrice <em>Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Price</em>'.
	 * @see excursions.metamodel.excursions.TripType#getPrice()
	 * @see #getTripType()
	 * @generated
	 */
	EAttribute getTripType_Price();

	/**
	 * Returns the meta object for the reference '{@link excursions.metamodel.excursions.TripType#getHistoryculture <em>Historyculture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Historyculture</em>'.
	 * @see excursions.metamodel.excursions.TripType#getHistoryculture()
	 * @see #getTripType()
	 * @generated
	 */
	EReference getTripType_Historyculture();

	/**
	 * Returns the meta object for the reference '{@link excursions.metamodel.excursions.TripType#getNatureoutdoor <em>Natureoutdoor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Natureoutdoor</em>'.
	 * @see excursions.metamodel.excursions.TripType#getNatureoutdoor()
	 * @see #getTripType()
	 * @generated
	 */
	EReference getTripType_Natureoutdoor();

	/**
	 * Returns the meta object for the reference '{@link excursions.metamodel.excursions.TripType#getThrilladventure <em>Thrilladventure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Thrilladventure</em>'.
	 * @see excursions.metamodel.excursions.TripType#getThrilladventure()
	 * @see #getTripType()
	 * @generated
	 */
	EReference getTripType_Thrilladventure();

	/**
	 * Returns the meta object for the reference '{@link excursions.metamodel.excursions.TripType#getShoppingsightseeing <em>Shoppingsightseeing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Shoppingsightseeing</em>'.
	 * @see excursions.metamodel.excursions.TripType#getShoppingsightseeing()
	 * @see #getTripType()
	 * @generated
	 */
	EReference getTripType_Shoppingsightseeing();

	/**
	 * Returns the meta object for class '{@link excursions.metamodel.excursions.ExcursionApp <em>Excursion App</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Excursion App</em>'.
	 * @see excursions.metamodel.excursions.ExcursionApp
	 * @generated
	 */
	EClass getExcursionApp();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.ExcursionApp#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see excursions.metamodel.excursions.ExcursionApp#getName()
	 * @see #getExcursionApp()
	 * @generated
	 */
	EAttribute getExcursionApp_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link excursions.metamodel.excursions.ExcursionApp#getTrips <em>Trips</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Trips</em>'.
	 * @see excursions.metamodel.excursions.ExcursionApp#getTrips()
	 * @see #getExcursionApp()
	 * @generated
	 */
	EReference getExcursionApp_Trips();

	/**
	 * Returns the meta object for class '{@link excursions.metamodel.excursions.HistoryCulture <em>History Culture</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>History Culture</em>'.
	 * @see excursions.metamodel.excursions.HistoryCulture
	 * @generated
	 */
	EClass getHistoryCulture();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.HistoryCulture#getHistoricCites <em>Historic Cites</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Historic Cites</em>'.
	 * @see excursions.metamodel.excursions.HistoryCulture#getHistoricCites()
	 * @see #getHistoryCulture()
	 * @generated
	 */
	EAttribute getHistoryCulture_HistoricCites();

	/**
	 * Returns the meta object for class '{@link excursions.metamodel.excursions.NatureOutdoor <em>Nature Outdoor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Nature Outdoor</em>'.
	 * @see excursions.metamodel.excursions.NatureOutdoor
	 * @generated
	 */
	EClass getNatureOutdoor();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.NatureOutdoor#getNatureCites <em>Nature Cites</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nature Cites</em>'.
	 * @see excursions.metamodel.excursions.NatureOutdoor#getNatureCites()
	 * @see #getNatureOutdoor()
	 * @generated
	 */
	EAttribute getNatureOutdoor_NatureCites();

	/**
	 * Returns the meta object for class '{@link excursions.metamodel.excursions.ThrillAdventure <em>Thrill Adventure</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Thrill Adventure</em>'.
	 * @see excursions.metamodel.excursions.ThrillAdventure
	 * @generated
	 */
	EClass getThrillAdventure();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.ThrillAdventure#getActivities <em>Activities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activities</em>'.
	 * @see excursions.metamodel.excursions.ThrillAdventure#getActivities()
	 * @see #getThrillAdventure()
	 * @generated
	 */
	EAttribute getThrillAdventure_Activities();

	/**
	 * Returns the meta object for class '{@link excursions.metamodel.excursions.ShoppingSightseeing <em>Shopping Sightseeing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Shopping Sightseeing</em>'.
	 * @see excursions.metamodel.excursions.ShoppingSightseeing
	 * @generated
	 */
	EClass getShoppingSightseeing();

	/**
	 * Returns the meta object for the attribute '{@link excursions.metamodel.excursions.ShoppingSightseeing#getAttractions <em>Attractions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Attractions</em>'.
	 * @see excursions.metamodel.excursions.ShoppingSightseeing#getAttractions()
	 * @see #getShoppingSightseeing()
	 * @generated
	 */
	EAttribute getShoppingSightseeing_Attractions();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ExcursionsFactory getExcursionsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link excursions.metamodel.excursions.impl.TripTypeImpl <em>Trip Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see excursions.metamodel.excursions.impl.TripTypeImpl
		 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getTripType()
		 * @generated
		 */
		EClass TRIP_TYPE = eINSTANCE.getTripType();

		/**
		 * The meta object literal for the '<em><b>Trip ID</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_TYPE__TRIP_ID = eINSTANCE.getTripType_TripID();

		/**
		 * The meta object literal for the '<em><b>Trip Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_TYPE__TRIP_NAME = eINSTANCE.getTripType_TripName();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_TYPE__DESCRIPTION = eINSTANCE.getTripType_Description();

		/**
		 * The meta object literal for the '<em><b>Duration</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_TYPE__DURATION = eINSTANCE.getTripType_Duration();

		/**
		 * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP_TYPE__PRICE = eINSTANCE.getTripType_Price();

		/**
		 * The meta object literal for the '<em><b>Historyculture</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_TYPE__HISTORYCULTURE = eINSTANCE.getTripType_Historyculture();

		/**
		 * The meta object literal for the '<em><b>Natureoutdoor</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_TYPE__NATUREOUTDOOR = eINSTANCE.getTripType_Natureoutdoor();

		/**
		 * The meta object literal for the '<em><b>Thrilladventure</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_TYPE__THRILLADVENTURE = eINSTANCE.getTripType_Thrilladventure();

		/**
		 * The meta object literal for the '<em><b>Shoppingsightseeing</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP_TYPE__SHOPPINGSIGHTSEEING = eINSTANCE.getTripType_Shoppingsightseeing();

		/**
		 * The meta object literal for the '{@link excursions.metamodel.excursions.impl.ExcursionAppImpl <em>Excursion App</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see excursions.metamodel.excursions.impl.ExcursionAppImpl
		 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getExcursionApp()
		 * @generated
		 */
		EClass EXCURSION_APP = eINSTANCE.getExcursionApp();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXCURSION_APP__NAME = eINSTANCE.getExcursionApp_Name();

		/**
		 * The meta object literal for the '<em><b>Trips</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EXCURSION_APP__TRIPS = eINSTANCE.getExcursionApp_Trips();

		/**
		 * The meta object literal for the '{@link excursions.metamodel.excursions.impl.HistoryCultureImpl <em>History Culture</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see excursions.metamodel.excursions.impl.HistoryCultureImpl
		 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getHistoryCulture()
		 * @generated
		 */
		EClass HISTORY_CULTURE = eINSTANCE.getHistoryCulture();

		/**
		 * The meta object literal for the '<em><b>Historic Cites</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HISTORY_CULTURE__HISTORIC_CITES = eINSTANCE.getHistoryCulture_HistoricCites();

		/**
		 * The meta object literal for the '{@link excursions.metamodel.excursions.impl.NatureOutdoorImpl <em>Nature Outdoor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see excursions.metamodel.excursions.impl.NatureOutdoorImpl
		 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getNatureOutdoor()
		 * @generated
		 */
		EClass NATURE_OUTDOOR = eINSTANCE.getNatureOutdoor();

		/**
		 * The meta object literal for the '<em><b>Nature Cites</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NATURE_OUTDOOR__NATURE_CITES = eINSTANCE.getNatureOutdoor_NatureCites();

		/**
		 * The meta object literal for the '{@link excursions.metamodel.excursions.impl.ThrillAdventureImpl <em>Thrill Adventure</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see excursions.metamodel.excursions.impl.ThrillAdventureImpl
		 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getThrillAdventure()
		 * @generated
		 */
		EClass THRILL_ADVENTURE = eINSTANCE.getThrillAdventure();

		/**
		 * The meta object literal for the '<em><b>Activities</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute THRILL_ADVENTURE__ACTIVITIES = eINSTANCE.getThrillAdventure_Activities();

		/**
		 * The meta object literal for the '{@link excursions.metamodel.excursions.impl.ShoppingSightseeingImpl <em>Shopping Sightseeing</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see excursions.metamodel.excursions.impl.ShoppingSightseeingImpl
		 * @see excursions.metamodel.excursions.impl.ExcursionsPackageImpl#getShoppingSightseeing()
		 * @generated
		 */
		EClass SHOPPING_SIGHTSEEING = eINSTANCE.getShoppingSightseeing();

		/**
		 * The meta object literal for the '<em><b>Attractions</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHOPPING_SIGHTSEEING__ATTRACTIONS = eINSTANCE.getShoppingSightseeing_Attractions();

	}

} //ExcursionsPackage
