/**
 */
package excursions.metamodel.excursions.impl;

import excursions.metamodel.excursions.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ExcursionsFactoryImpl extends EFactoryImpl implements ExcursionsFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ExcursionsFactory init() {
		try {
			ExcursionsFactory theExcursionsFactory = (ExcursionsFactory) EPackage.Registry.INSTANCE
					.getEFactory(ExcursionsPackage.eNS_URI);
			if (theExcursionsFactory != null) {
				return theExcursionsFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ExcursionsFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExcursionsFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ExcursionsPackage.EXCURSION_APP:
			return createExcursionApp();
		case ExcursionsPackage.HISTORY_CULTURE:
			return createHistoryCulture();
		case ExcursionsPackage.NATURE_OUTDOOR:
			return createNatureOutdoor();
		case ExcursionsPackage.THRILL_ADVENTURE:
			return createThrillAdventure();
		case ExcursionsPackage.SHOPPING_SIGHTSEEING:
			return createShoppingSightseeing();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExcursionApp createExcursionApp() {
		ExcursionAppImpl excursionApp = new ExcursionAppImpl();
		return excursionApp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HistoryCulture createHistoryCulture() {
		HistoryCultureImpl historyCulture = new HistoryCultureImpl();
		return historyCulture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NatureOutdoor createNatureOutdoor() {
		NatureOutdoorImpl natureOutdoor = new NatureOutdoorImpl();
		return natureOutdoor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThrillAdventure createThrillAdventure() {
		ThrillAdventureImpl thrillAdventure = new ThrillAdventureImpl();
		return thrillAdventure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShoppingSightseeing createShoppingSightseeing() {
		ShoppingSightseeingImpl shoppingSightseeing = new ShoppingSightseeingImpl();
		return shoppingSightseeing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExcursionsPackage getExcursionsPackage() {
		return (ExcursionsPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ExcursionsPackage getPackage() {
		return ExcursionsPackage.eINSTANCE;
	}

} //ExcursionsFactoryImpl
