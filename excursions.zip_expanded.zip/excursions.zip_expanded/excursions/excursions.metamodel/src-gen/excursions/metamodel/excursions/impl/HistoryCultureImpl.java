/**
 */
package excursions.metamodel.excursions.impl;

import excursions.metamodel.excursions.ExcursionsPackage;
import excursions.metamodel.excursions.HistoryCulture;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>History Culture</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.impl.HistoryCultureImpl#getHistoricCites <em>Historic Cites</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HistoryCultureImpl extends TripTypeImpl implements HistoryCulture {
	/**
	 * The default value of the '{@link #getHistoricCites() <em>Historic Cites</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHistoricCites()
	 * @generated
	 * @ordered
	 */
	protected static final String HISTORIC_CITES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHistoricCites() <em>Historic Cites</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHistoricCites()
	 * @generated
	 * @ordered
	 */
	protected String historicCites = HISTORIC_CITES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HistoryCultureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExcursionsPackage.Literals.HISTORY_CULTURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHistoricCites() {
		return historicCites;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHistoricCites(String newHistoricCites) {
		String oldHistoricCites = historicCites;
		historicCites = newHistoricCites;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.HISTORY_CULTURE__HISTORIC_CITES,
					oldHistoricCites, historicCites));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ExcursionsPackage.HISTORY_CULTURE__HISTORIC_CITES:
			return getHistoricCites();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ExcursionsPackage.HISTORY_CULTURE__HISTORIC_CITES:
			setHistoricCites((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.HISTORY_CULTURE__HISTORIC_CITES:
			setHistoricCites(HISTORIC_CITES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.HISTORY_CULTURE__HISTORIC_CITES:
			return HISTORIC_CITES_EDEFAULT == null ? historicCites != null
					: !HISTORIC_CITES_EDEFAULT.equals(historicCites);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (historicCites: ");
		result.append(historicCites);
		result.append(')');
		return result.toString();
	}

} //HistoryCultureImpl
