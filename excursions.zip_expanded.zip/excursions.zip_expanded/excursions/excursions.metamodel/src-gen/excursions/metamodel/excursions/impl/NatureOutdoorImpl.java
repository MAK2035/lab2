/**
 */
package excursions.metamodel.excursions.impl;

import excursions.metamodel.excursions.ExcursionsPackage;
import excursions.metamodel.excursions.NatureOutdoor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Nature Outdoor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.impl.NatureOutdoorImpl#getNatureCites <em>Nature Cites</em>}</li>
 * </ul>
 *
 * @generated
 */
public class NatureOutdoorImpl extends TripTypeImpl implements NatureOutdoor {
	/**
	 * The default value of the '{@link #getNatureCites() <em>Nature Cites</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNatureCites()
	 * @generated
	 * @ordered
	 */
	protected static final String NATURE_CITES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNatureCites() <em>Nature Cites</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNatureCites()
	 * @generated
	 * @ordered
	 */
	protected String natureCites = NATURE_CITES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NatureOutdoorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExcursionsPackage.Literals.NATURE_OUTDOOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNatureCites() {
		return natureCites;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNatureCites(String newNatureCites) {
		String oldNatureCites = natureCites;
		natureCites = newNatureCites;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.NATURE_OUTDOOR__NATURE_CITES,
					oldNatureCites, natureCites));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ExcursionsPackage.NATURE_OUTDOOR__NATURE_CITES:
			return getNatureCites();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ExcursionsPackage.NATURE_OUTDOOR__NATURE_CITES:
			setNatureCites((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.NATURE_OUTDOOR__NATURE_CITES:
			setNatureCites(NATURE_CITES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.NATURE_OUTDOOR__NATURE_CITES:
			return NATURE_CITES_EDEFAULT == null ? natureCites != null : !NATURE_CITES_EDEFAULT.equals(natureCites);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (natureCites: ");
		result.append(natureCites);
		result.append(')');
		return result.toString();
	}

} //NatureOutdoorImpl
