/**
 */
package excursions.metamodel.excursions;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trip Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.TripType#getTripID <em>Trip ID</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getTripName <em>Trip Name</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getDescription <em>Description</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getDuration <em>Duration</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getPrice <em>Price</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getHistoryculture <em>Historyculture</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getNatureoutdoor <em>Natureoutdoor</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getThrilladventure <em>Thrilladventure</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.TripType#getShoppingsightseeing <em>Shoppingsightseeing</em>}</li>
 * </ul>
 *
 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType()
 * @model abstract="true"
 * @generated
 */
public interface TripType extends EObject {
	/**
	 * Returns the value of the '<em><b>Trip ID</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trip ID</em>' attribute.
	 * @see #setTripID(int)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_TripID()
	 * @model
	 * @generated
	 */
	int getTripID();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getTripID <em>Trip ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trip ID</em>' attribute.
	 * @see #getTripID()
	 * @generated
	 */
	void setTripID(int value);

	/**
	 * Returns the value of the '<em><b>Trip Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trip Name</em>' attribute.
	 * @see #setTripName(String)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_TripName()
	 * @model
	 * @generated
	 */
	String getTripName();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getTripName <em>Trip Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trip Name</em>' attribute.
	 * @see #getTripName()
	 * @generated
	 */
	void setTripName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Duration</em>' attribute.
	 * @see #setDuration(int)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_Duration()
	 * @model
	 * @generated
	 */
	int getDuration();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getDuration <em>Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Duration</em>' attribute.
	 * @see #getDuration()
	 * @generated
	 */
	void setDuration(int value);

	/**
	 * Returns the value of the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Price</em>' attribute.
	 * @see #setPrice(float)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_Price()
	 * @model
	 * @generated
	 */
	float getPrice();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getPrice <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Price</em>' attribute.
	 * @see #getPrice()
	 * @generated
	 */
	void setPrice(float value);

	/**
	 * Returns the value of the '<em><b>Historyculture</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Historyculture</em>' reference.
	 * @see #setHistoryculture(HistoryCulture)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_Historyculture()
	 * @model derived="true"
	 * @generated
	 */
	HistoryCulture getHistoryculture();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getHistoryculture <em>Historyculture</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Historyculture</em>' reference.
	 * @see #getHistoryculture()
	 * @generated
	 */
	void setHistoryculture(HistoryCulture value);

	/**
	 * Returns the value of the '<em><b>Natureoutdoor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Natureoutdoor</em>' reference.
	 * @see #setNatureoutdoor(NatureOutdoor)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_Natureoutdoor()
	 * @model derived="true"
	 * @generated
	 */
	NatureOutdoor getNatureoutdoor();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getNatureoutdoor <em>Natureoutdoor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Natureoutdoor</em>' reference.
	 * @see #getNatureoutdoor()
	 * @generated
	 */
	void setNatureoutdoor(NatureOutdoor value);

	/**
	 * Returns the value of the '<em><b>Thrilladventure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Thrilladventure</em>' reference.
	 * @see #setThrilladventure(ThrillAdventure)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_Thrilladventure()
	 * @model derived="true"
	 * @generated
	 */
	ThrillAdventure getThrilladventure();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getThrilladventure <em>Thrilladventure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Thrilladventure</em>' reference.
	 * @see #getThrilladventure()
	 * @generated
	 */
	void setThrilladventure(ThrillAdventure value);

	/**
	 * Returns the value of the '<em><b>Shoppingsightseeing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Shoppingsightseeing</em>' reference.
	 * @see #setShoppingsightseeing(ShoppingSightseeing)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getTripType_Shoppingsightseeing()
	 * @model derived="true"
	 * @generated
	 */
	ShoppingSightseeing getShoppingsightseeing();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.TripType#getShoppingsightseeing <em>Shoppingsightseeing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Shoppingsightseeing</em>' reference.
	 * @see #getShoppingsightseeing()
	 * @generated
	 */
	void setShoppingsightseeing(ShoppingSightseeing value);

} // TripType
