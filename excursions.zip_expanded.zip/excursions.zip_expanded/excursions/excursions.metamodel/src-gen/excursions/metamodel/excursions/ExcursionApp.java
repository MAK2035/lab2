/**
 */
package excursions.metamodel.excursions;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Excursion App</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.ExcursionApp#getName <em>Name</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.ExcursionApp#getTrips <em>Trips</em>}</li>
 * </ul>
 *
 * @see excursions.metamodel.excursions.ExcursionsPackage#getExcursionApp()
 * @model
 * @generated
 */
public interface ExcursionApp extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getExcursionApp_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.ExcursionApp#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Trips</b></em>' containment reference list.
	 * The list contents are of type {@link excursions.metamodel.excursions.TripType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trips</em>' containment reference list.
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getExcursionApp_Trips()
	 * @model containment="true"
	 * @generated
	 */
	EList<TripType> getTrips();

} // ExcursionApp
